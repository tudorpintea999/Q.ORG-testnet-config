#! /bin/bash
docker-compose -f js-tools-in-docker.yml run --rm nodejs
docker run --rm -v $PWD/config-minimal.json:/build/config.json qblockchain/js-interface:testnet info.js

# Clef setup for validator
Not secure and not recomended to use yet

## Adding validator keystorefile
 - add keystrore-file to folder keystore
 - `docker-compose -f docker-compose-init.yaml run --rm --entrypoint "clef setpw $ADDRESS" signer-init`

## init 
  - `./init.sh`

## docker-compose up here
  - `./up.sh`

function ApproveTx(req) {
    if (req.transaction.data.toLowerCase() == "0xb3b22163")
    return "Approve"
}
function ApproveSignData(req) {
    return "Approve"
}

// Approve listings if request made from IPC
function ApproveListing(req) {
    return "Approve"
    }


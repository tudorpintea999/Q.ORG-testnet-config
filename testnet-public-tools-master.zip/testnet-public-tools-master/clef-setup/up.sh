#! /usr/bin/bash

echo Enter masterseed password && 
    read -s TMP && 
    TMP=$TMP docker-compose up -d
